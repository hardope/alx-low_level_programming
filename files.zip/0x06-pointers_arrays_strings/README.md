**More Pointers, Arrays and Strings**
