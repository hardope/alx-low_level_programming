#include <stdio.h>

/**
 * main - Print a string
 * Description: use printf
 * Return: 0
 */

int main(void)
{
	printf("%s", "with proper grammar, but the outcome is a piece of art,\n");
	return (0);
}
