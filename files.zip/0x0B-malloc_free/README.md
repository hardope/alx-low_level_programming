**0x0B. C - malloc, free**
