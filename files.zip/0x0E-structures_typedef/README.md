**0x0E. C - Structures, typedef**
