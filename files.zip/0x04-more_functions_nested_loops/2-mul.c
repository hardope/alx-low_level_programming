#include "holberton.h"

/**
 * mul - gives the product of a and b
 * @a: variable
 * @b: variable
 *
 * Return: a * b
 */

int mul(int a, int b)
{
return (a * b);
}
