#include "holberton.h"

/**
 * main - check my code
 *
 * Return: Always 0
 */

int main(void)
{
	more_numbers();
	return (0);
}
