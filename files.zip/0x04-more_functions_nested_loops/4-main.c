#include "holberton.h"

/**
 * main - checks my code
 *
 * Return: 0
 */

int main(void)
{
	print_most_numbers();
	return (0);
}
