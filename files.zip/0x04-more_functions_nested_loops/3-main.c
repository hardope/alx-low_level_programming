#include "holberton.h"

/**
 * main - checks my code
 *
 * Return: Always 0
 */

int main(void)
{
	print_numbers();
	return (0);
}
