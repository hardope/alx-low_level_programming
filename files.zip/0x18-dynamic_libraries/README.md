# 0x18-dynamic_libraries
In this project, I learnt how to create dynamic libraries from modules and use them
