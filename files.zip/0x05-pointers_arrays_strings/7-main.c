#include "holberton.h"

int main(void)
{
	char *str;

	str = "0123456789";
	puts_half(str);
	return (0);
}
