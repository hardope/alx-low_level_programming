#include "holberton.h"

int main(void)
{
	char *str;

	str = "I do not fear computers. i fear the lack of them - isaac Asimov";
	_puts(str);
	return (0);
}
