#include "holberton.h"

/**
 * reset_to_98 - updates the value of n to 98
 * @n: integer pointer to a variable to be updated
 *
 * Return: nothing
 */

void reset_to_98(int *n)
{
	*n = 98;
}
