**0x05. C - Pointers, arrays and strings**
